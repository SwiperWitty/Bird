#include "stc15.h"
#include "led.h"
#include "delay.h"
#include "uart.h"
#include "adc.h"
#include "code_handle.h"
#include "typedefine.h"

#define LED_ON 0
#define LED_OF 1
#define Bzz_ON 0
#define Bzz_OF 1
#define KEY_ON 1
#define KEY_OF 0
#define ABat 2 //0.02A 0.06V	2A 1V;  	16.5w 0.42V
#define VBat 3 // 3.3 * Multiple_V	= 18.645V
#define VTEM 4 //2.2V  17 C
#define Multiple_V 5810

sbit KEY0 = P5 ^ 5; // Power Switch
sbit Bzz = P1 ^ 5;	// Bzz Sound
sbit EleC = P1 ^ 0; // Electric Current
sbit LEDP = P1 ^ 1; // Power indicator

float ADC_Data;
char time1 = 0,time2 = 0,time3 = 0;
unsigned char X_S,ARRAY[2];
int L_EleC , L_LEDP,EleC_test;
unsigned char Mode = ' ',ADC_Channle = 2;
struct
{
	unsigned int ADC_Temp;		//ADC源数据
	unsigned int Temp;
	unsigned int EleC;		//ADC源数据
	unsigned int ADC_Bat;	//ADC源数据
	unsigned int BatV;		//电池电压
}Voltage;

void Uart (void);
void Initialize(void);

															/* 2021 04 08 */
void main(void)
{
	Initialize();
	while (1)
	{
		ADC_Data = Voltage.ADC_Bat;
		ADC_Data = (ADC_Data / 1024) * 3.3;
		Voltage.BatV = (ADC_Data * Multiple_V);

		ADC_Data = Voltage.ADC_Temp;
		ADC_Data = (ADC_Data / 1024) * 3.3;
		Voltage.Temp = ADC_Data * 1000;
		
		if (Voltage.Temp < 2300)				//
		{
			LED_RGB('R');	
			//Bzz = Bzz_ON;
			if (Voltage.Temp < 1800)			//
			{
				time2++;
				if(time2 > 2) KEY0 = KEY_OF;
			}
		}
		else
			LED_RGB('G');
		if (X_S == '0' || X_S == ' ')
		{
		}
		else if (Voltage.BatV < 3700 * (X_S - '0'))
		{
			time3++;
			if(time3 > 2) KEY0 = KEY_OF;						// 过放电压
		}
		
		if (X_S == '2')
		{
			L_LEDP = (Voltage.BatV - 7300) / 15;
		}
		else if (X_S == '3')
		{
			L_LEDP = (Voltage.BatV  - 11100) / 20;
		}
		else if (X_S == '4')
		{
			L_LEDP = (Voltage.BatV  - 14700) / 28;
		}
		else
		{
			L_LEDP = 80;
		}
		if (L_LEDP >= 80)
			L_LEDP = 80;
		
		Uart ();
		if(Mode == 'V' || Mode == 'C')
		{
			UARTX_Send(1, Num_Sting(Voltage.BatV, 5, 3, 'V'), 8);
			Delayx00ms(1);
			UARTX_Send(1, "\r\n", sizeof("\r\n"));
			Delayx00ms(1);
		}
		if(Mode == 'T' || Mode == 'C')
		{
			UARTX_Send(1, Num_Sting(Voltage.Temp, 5, 3, 'C'), 8);
			Delayx00ms(1);
			UARTX_Send(1, "\r\n", sizeof("\r\n"));
			Delayx00ms(1);
		}
		if(Mode == 'A' || Mode == 'C')
		{
			UARTX_Send(1, Num_Sting(Voltage.EleC, 5, 3, 'A'), 8);
			Delayx00ms(1);
			UARTX_Send(1, "\r\n", sizeof("\r\n"));
			Delayx00ms(1);
			UARTX_Send(1, "\r\n", sizeof("\r\n"));
			Delayx00ms(1);
		}
	}
}

void Uart (void)
{
	if(TCount > 3000 || RXD_Flag == 1)
	{
		TCount = 0;
		r_1 = 0;
		
		Delayx00ms(1);
		if(array_r[0] == '{')
		{
			if(array_r[1] == 'B' && array_r[2] == 'i' && array_r[3] == 'r' && array_r[4] == 'd')
			{
				if(array_r[5] == '-')
				{
					if(array_r[6] == 'o' && array_r[7] == 'n');
					else
						KEY0 = KEY_OF;
					UARTX_Send(1, "OK !\r\n", sizeof("OK !\r\n"));
				}
				else if(array_r[5] == ':')
				{
					Mode = array_r[6];
				}
			}
		}
		else
		{
			UARTX_Send(1, "Error !\r\n", sizeof("Error !\r\n"));
		}
		Clean(sizeof(array_r),array_r);
	}
	RXD_Flag = 0;
}

void TIME0_IRQ(void) NVIC(1)
{
	TF0 = 0;
	if (r_1)
	{
		TCount++;
		if (TCount > 10000)
		TCount = 12000;
	}
	else
		TCount = 0;

	Timer0++;

	if (Timer0 > 200)
	{
		Timer0 = 0;
	}
	if (L_EleC >= Timer0)
	{
		EleC = LED_ON;
	}
	else
		EleC = LED_OF;
	if (L_LEDP >= Timer0)
	{
		LEDP = LED_ON;
	}
	else
		LEDP = LED_OF;
}

void ADC_IRQ(void) NVIC(5)
{
	unsigned int num;
	ADC_CONTR &= ~ADC_FLAG;
	if(ADC_Channle == ABat)
	{
		Voltage.EleC = ADC_RES;
		if (Voltage.EleC > 126)
		{
			time1++;
			if(time1 >= 2)
			{
				KEY0 = KEY_OF;
				LED_RGB('B');
			}
		}
		else time1 = 0;
		L_EleC = Voltage.EleC;
	}
	else if(ADC_Channle == VBat)
	{
		num = ADC_RES;
		num = (num << 2) + ADC_RESL;
		Voltage.ADC_Bat = num;
	}
	else if(ADC_Channle == VTEM)
	{
		num = ADC_RES;
		num = (num << 2) + ADC_RESL;
		Voltage.ADC_Temp = num;
	}
	ADC_Channle++;													// 通道切换
	if(ADC_Channle > VTEM) ADC_Channle = ABat;
	ADC_CONTR = ADC_POWER | ADC_SPEEDH | ADC_START | ADC_Channle;
}

void Initialize(void)
{
	KEY0 = 1;
	LED_RGB('R');
	Bzz = Bzz_ON;
	EleC = LED_ON;
	LEDP = LED_ON;
	Uart_Init(UART1);
	Delayx00ms(1);
	Bzz = Bzz_OF;
	EleC = LED_OF;
	LEDP = LED_OF;
	Voltage.BatV = GPIOX_ADCY(1, VBat, ADC_SPEEDL) * 5.65; //
	if (Voltage.BatV < 7000)
		X_S = '0'; //
	else if (Voltage.BatV > 7300 && Voltage.BatV < 8500)
		X_S = '2'; //2S
	else if (Voltage.BatV > 11000 && Voltage.BatV < 12700)
		X_S = '3'; //3S
	else if (Voltage.BatV > 14700 && Voltage.BatV < 16900)
		X_S = '4'; //4S
	else
		X_S = ' '; //
	P1ASF = ~0XE3;								//模拟功能A/D使用
	P1M0 &= 0XE3;
	P1M1 |= ~0XE3;
	ADC_CONTR = (ADC_POWER | ADC_SPEEDL | ADC_Channle);
	ADC_CONTR |= ADC_START;

	UARTX_Send(UART1,"{This battery is ",sizeof("{This battery is "));
	ARRAY[0] = X_S;
	Delayx00ms(1);
	UARTX_Send(UART1,ARRAY,1);
	Delayx00ms(1);
	UARTX_Send(UART1," S}",sizeof(" S "));
	Delayx00ms(1);
	UARTX_Send(UART1," \r\n",sizeof(" \r\n"));
	L_EleC = 0;
	L_LEDP = 0;
	EA = 1;
	EADC = 1;
}
