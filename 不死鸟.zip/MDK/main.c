#include "stc15.h"
#include "led.h"
#include "delay.h"
#include "uart.h"
#include "adc.h"
#include "Data_Handle.h"
#include "typedefine.h"

/********						24Mhz  9600				  *************

这个版本基本没啥问题就是，内存不够了，还有NTC的温度采集并不是准确的温度
NTC 10K （常温大概 5K）  定值电阻5.6K（接5V端）

ADC_num = (3.3 / 4095) * ADC_num;
Temp_NTC = ADC_num;
RES_NTC = (RES_Fixed * Temp_NTC) / (3.3 - Temp_NTC);
Temp_NTC = 58.68 - (RES_NTC * (3.368));

25° ->  10K
38° ->  6.14K

简单性线温度计算方法，但是STC单片机算力有限，不建议这么来。

命令：

{Bird-on}   开mos（没用）
{Bird-off}  关mos

***************

指令：

{Bird:V}   电压
{Bird:A}   电流
{Bird:T}   温度
{Bird:C}   全部显示
{Bird: }   全部不显示

V1.2											不死鸟

!!!!!!  2S电池 电流有些问题 自己试试吧！

*********************************/

#define LED_ON 0
#define LED_OF 1
#define Bzz_ON 0
#define Bzz_OF 1
#define KEY_ON 1
#define KEY_OF 0
#define ABat 2 									//0.02A 0.06V	2A 1V  	16.5w 0.42V
#define VBat 3 									// 3.3 * Multiple_V	= 18.645V
#define VTEM 4 									//2.2V  17 C
#define Multiple_V 5.81			
#define BatMIN 3.7
#define BatMAX 4.2
#define MAX_A 126								//最大电流

sbit KEY0 = P5 ^ 5; // Power Switch
sbit Bzz = P1 ^ 5;	// Bzz Sound
sbit EleC = P1 ^ 0; // Electric Current
sbit LEDP = P1 ^ 1; // Power indicator

float ADC_Data;
char time1 = 0,time2 = 0,time3 = 0;
char Mode = ' ',ADC_Channle = 2;
int L_EleC,L_LEDP,EleC_test,X_S;

struct
{
	unsigned int ADC_Temp;		//ADC源数据
	float Temp;
	unsigned int EleC;		//ADC源数据
	unsigned int ADC_Bat;	//ADC源数据
	float BatV;		//电池电压
}Voltage;

void Uart_Handle (void);
void String_Show (void);
void Initialize(void);

															/* 2021 04 08 */
void main(void)
{
	Initialize();
	while (1)
	{
		ADC_Data = Voltage.ADC_Bat;
		ADC_Data = (ADC_Data / 1024) * 3.3;
		Voltage.BatV = (ADC_Data * Multiple_V);

		ADC_Data = Voltage.ADC_Temp;
		Voltage.Temp = (ADC_Data / 1024) * 3.3;
		
		if (Voltage.Temp < 2.3)								//
		{
			LED_RGB('R');	
			//Bzz = Bzz_ON;
			if (Voltage.Temp < 1.8)							// 过温保护
			{
				time2++;
				if(time2 > 2) KEY0 = KEY_OF;
			}
		}
		else
			LED_RGB('G');
		if (X_S == 0)
		{
		}
		else if (Voltage.BatV < BatMIN * X_S)
		{
			time3++;
			if(time3 > 2) KEY0 = KEY_OF;						// 过放电压
		}
		
		if (X_S == 2)
		{
			L_LEDP = (Voltage.BatV - 7.3) * 65;
		}
		else if (X_S == 3)
		{
			L_LEDP = (Voltage.BatV  - 11.1) * 50;
		}
		else if (X_S == 4)
		{
			L_LEDP = (Voltage.BatV  - 14.7) * 35;
		}
		else
		{
			L_LEDP = 80;
		}
		if (L_LEDP >= 80)
			L_LEDP = 80;
		
		Uart_Handle ();
		String_Show ();
	}
}

void Uart_Handle (void)
{
	if(RXD_Flag == 1)
	{
		if(String_Compare(array_r,"{Bird",sizeof("{Bird")) )
		{
			if(array_r[5] == '-')
			{
				if(String_Compare(array_r,"{Bird-on}",sizeof("{Bird-on}")) )
				{
					KEY0 = KEY_ON;
					UARTX_Send(1, "OK !\r\n", sizeof("OK !\r\n"));
				}
				else KEY0 = KEY_OF;
			}
			else if(array_r[5] == ':')
			{
				Mode = array_r[6];
			}
		}
		else	UARTX_Send(1, "ERROR !\r\n", sizeof("ERROR !\r\n"));
		String_Replace ("F",array_r,0,sizeof(array_r));
		RXD_Flag = 0;
	}
}

void String_Show (void)
{
	if(Mode == 'V' || Mode == 'C')
	{
		sprintf(array_s,"{Val is %.3f V}\r\n",Voltage.BatV);
		UARTX_Send(UART1,array_s,sizeof(array_s));
		String_Replace ("F",array_s,0,sizeof(array_s));
		Delayx00ms(1);
	}
	if(Mode == 'T' || Mode == 'C')
	{
		sprintf(array_s,"{Temp is %05.2f C}\r\n",Voltage.Temp);
		UARTX_Send(UART1,array_s,sizeof(array_s));
		String_Replace ("F",array_s,0,sizeof(array_s));
		Delayx00ms(1);
	}
	if(Mode == 'A' || Mode == 'C')
	{
		sprintf(array_s,"{EC-A is : %d }\r\n",Voltage.EleC);
		UARTX_Send(UART1,array_s,sizeof(array_s));
		String_Replace ("F",array_s,0,sizeof(array_s));
		Delayx00ms(1);
		UARTX_Send(1, "\r\n", sizeof("\r\n"));
		Delayx00ms(1);
	}
}

void TIME0_IRQ(void) NVIC(1)				//定时器1中断
{
	TF0 = 0;
	Timer0++;

	if (Timer0 > 200)
	{
		Timer0 = 0;
	}
	if (L_EleC >= Timer0)
	{
		EleC = LED_ON;
	}
	else
		EleC = LED_OF;
	if (L_LEDP >= Timer0)
	{
		LEDP = LED_ON;
	}
	else
		LEDP = LED_OF;
}

void ADC_IRQ(void) NVIC(5)				//ADC通道中断
{
	unsigned int num;
	ADC_CONTR &= ~ADC_FLAG;
	if(ADC_Channle == ABat)
	{
		Voltage.EleC = ADC_RES;
		if (Voltage.EleC > MAX_A)
		{
			time1++;
			if(time1 >= 2)
			{
				KEY0 = KEY_OF;
				LED_RGB('B');
			}
		}
		else time1 = 0;
		L_EleC = Voltage.EleC;
	}
	else if(ADC_Channle == VBat)
	{
		num = ADC_RES;
		num = (num << 2) + ADC_RESL;
		Voltage.ADC_Bat = num;
	}
	else if(ADC_Channle == VTEM)
	{
		num = ADC_RES;
		num = (num << 2) + ADC_RESL;
		Voltage.ADC_Temp = num;
	}
	ADC_Channle++;													// 通道切换
	if(ADC_Channle > VTEM) ADC_Channle = ABat;
	ADC_CONTR = ADC_POWER | ADC_SPEEDH | ADC_START | ADC_Channle;
}

void Initialize(void)
{
	KEY0 = 1;
	LED_RGB('R');
	Bzz = Bzz_ON;
	EleC = LED_ON;
	LEDP = LED_ON;
	Uart_Init(UART1);
	Delayx00ms(1);
	Bzz = Bzz_OF;
	EleC = LED_OF;
	LEDP = LED_OF;
	Voltage.BatV = GPIOX_ADCY(1, VBat, ADC_SPEEDL) * 5.65; //
	if (Voltage.BatV < 4400 && Voltage.BatV > 3500)
		X_S = 1; //
	else if (Voltage.BatV > 7300 && Voltage.BatV < 8500)
		X_S = 2; //2S
	else if (Voltage.BatV > 11000 && Voltage.BatV < 12700)
		X_S = 3; //3S
	else if (Voltage.BatV > 14700 && Voltage.BatV < 16900)
		X_S = 4; //4S
	else
		X_S = 0; //
	P1ASF = ~0XE3;								//模拟功能A/D使用
	P1M0 &= 0XE3;
	P1M1 |= ~0XE3;
	ADC_CONTR = (ADC_POWER | ADC_SPEEDL | ADC_Channle);
	ADC_CONTR |= ADC_START;

	sprintf(array_s,"Bird V%.1f \r\n",1.2);
	UARTX_Send(UART1,array_s,sizeof(array_s));
	String_Replace ("F",array_s,0,sizeof(array_s));
	Delayx00ms(1);
	sprintf(array_s,"{This bat is %d S}\r\n",X_S);
	UARTX_Send(UART1,array_s,sizeof(array_s));
	String_Replace ("F",array_s,0,sizeof(array_s));
	L_EleC = 0;
	L_LEDP = 0;
	EA = 1;
	EADC = 1;
}
