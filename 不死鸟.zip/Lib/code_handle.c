#include "code_handle.h"

void Code_Replace(char Length, char Origin, char *target, const char *array)
{
    char n;
    for (n = 0; n < Length; n++)
    {
        *(target + Origin + n) = *(array + n);
    }
}

char *Num_Sting(unsigned int num, char Length, char decimal, char unit) //数据格式处理  3300 -> 3.300 v  11700 -> 11.700 v
{
    unsigned int Mul = 1;
    char NUM_array[10]; //  xx'.'xxx" %"
    char n;
    //总长度
    for (n = Length; n >= 0; n--)
    {
        if (n == (Length - decimal))            //确定小数点
            n--;
        NUM_array[n] = (num / Mul) % 10 + '0';
        Mul *= 10;
    }
    if (decimal < Length)
        NUM_array[Length - decimal] = '.';
    NUM_array[Length + 1] = ' ';
    NUM_array[Length + 2] = unit;

    return & NUM_array;
}
