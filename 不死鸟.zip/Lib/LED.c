#include "led.h"
#include "stc15.h"

sbit LED_R = P3 ^ 7;
sbit LED_G = P3 ^ 6;
sbit LED_B = P3 ^ 3;

void LED_RGB(const char Color)
{
	LED_R = LED_OF;
    LED_G = LED_OF;
    LED_B = LED_OF;
	switch(Color)
	{
		case 'R':	LED_R = LED_ON; break;
		case 'G':	LED_G = LED_ON; break;
		case 'B':	LED_B = LED_ON; break;
		default : break;								//不符合直接关闭所有灯
	}
}
