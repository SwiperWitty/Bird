#ifndef _DATA_HANDLE_H__
#define _DATA_HANDLE_H__

/*				纯C#数据处理算法

	1.数组分割处理
	2.数据转换


							2021.05.10

sprintf(array,"NUM =  %.2f C \r\n",float(num));
sprintf(array,"NUM =  %d C   \r\n",num);
%05.2f :
%开始符；
0是 "填空字元" 表示,如果长度不足时就用0来填满；
8格式化后总长度；
2f小数位长度，即2位；
************************************/
#include "stdio.h"


void String_Replace (char *Origin,char *Target,char Data,char Length);		// Origin 来源	Target 替代目标		Data 源（单字节）	Length 长度

char String_Compare (char *Origin,char *Target,char Length);				// Origin 来源	Target 对比目标		Length 长度

//unsigned int String_NUM_to_int_NUM(char *Sting, char Length);				// 读取字符串中的数字（一组数字 65000 以内）


#endif
