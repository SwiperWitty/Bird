#ifndef LED_H_
#define LED_H_

#define LED_ON 0
#define LED_OF 1

void LED_RGB(const char Color);

#endif
