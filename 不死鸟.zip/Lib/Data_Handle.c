#include "Data_Handle.h"

int n,m;

void String_Replace (char *Origin,char *Target,char Data,char Length)
{
	if (Length > 30)
	{
		Length = 30;
	}
	for(n = 0;n < Length;n++)
	{
		if(Data == 'F')
		{
			*(Target + n) = *(Origin + n);
		}
		else 
		{
			*(Target + n) = Data;
		}
	}
}

char String_Compare (char *Origin,char *Target,char Length)
{
	if (Length > 30)
	{
		Length = 30;
	}
	for (n = 0; n < Length - 1; n)
	{
		if(* (Origin + n) == * (Target + n)) n++;
		else	return 0;
	}
	return 1;
}

//unsigned int String_NUM_to_int_NUM(char *Sting, char Length)
//{
//	unsigned int num = 0;
//	char dat, End, Start = '0'; 					// 从 array[Init] 开始，到 array[Init+m] 都是需要转换的数字
//	m = 0;					 						// 字符串中 连续数字的个数
//	if (Length > 30)
//	{
//		Length = 30;
//	}
//	for (n = 0; n < Length; n++)
//	{
//		dat = *(Sting + n);
//		if (dat >= '0' && dat <= '9')
//		{
//			m++;
//			if (Start == '0') 						// 只执行一次
//			{
//				Start = n;							// 读取开始为数字的 n位（从n开始之后的m个数都是数字）
//			}
//		}
//		else if (m > 0)								// 当m不为零，且dat不为数字时，退出for
//			break; 
//	}
//	if (Start != '0')
//	{
//		End = m + Start; // Start 头		End 尾
//		for (n = Start; n < End; n++)
//		{
//			dat = *(Sting + n);
//			num = num * 10 + (dat - '0');
//		}
//	}
//	return num;
//}


