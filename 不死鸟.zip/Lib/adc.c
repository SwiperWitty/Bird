#include "STC15.h"
#include "delay.h"
#include "adc.h"

/*
	低速采样 ADC
*/

unsigned int GPIOX_ADCY(unsigned char Px, unsigned char ADCX,unsigned char Speed)
{
	float i;
	unsigned int num = 0;
	/*PxM1.n,PxM0.n     =00--->Standard,    01--->push-pull
						=10--->pure input,  11--->open drain	*/
	if (ADCX > 7)
		return 0;
	if (Px == 1 || Px == '1')
	{
		P1ASF = (0X01 << ADCX);								//使能 ADC
		P1M0 &= ~(0X01 << ADCX);
		P1M1 |= (0X01 << ADCX);
	}
	else return 0;
	EADC = 0;												//关闭 ADC中断
	ADC_RES = 0;
	ADC_CONTR = (ADC_POWER | Speed | ADCX);
	ADC_CONTR |= ADC_START;
	Delayx0us(1);
	while (!(ADC_CONTR & ADC_FLAG));					//等待 ADC结束
	ADC_CONTR &= ~ADC_FLAG; 							//清除标志位
	if(Speed <= ADC_SPEEDL)								//速度选择
	{
		num = ADC_RES;
		num = (num << 2) + ADC_RESL;
		i = num;
		i = (i / 1024) * 3.3;
		num = i * 1000;
	}
	else
	{
		num = ADC_RES;
	}
	ADC_CONTR &= ~ADC_START;
	return num;
}

/*
			中断
*/

//void ADC_IRQ() interrupt 5
//{
//	
//}
