#ifndef _code_handle_h
#define _code_handle_h

char * Num_Sting (unsigned int num,char Length,char decimal,char unit);

#endif
