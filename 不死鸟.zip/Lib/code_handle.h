#ifndef _code_handle_h
#define _code_handle_h

void Code_Replace (char Length,char Origin,char *target,const char *array);
char * Num_Sting (unsigned int num,char Length,char decimal,char unit);

#endif
