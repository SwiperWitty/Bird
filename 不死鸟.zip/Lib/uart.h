#ifndef _UART__H_

#define _UART__H_

#define UART1 1
#define UART2 2

#include "code_handle.h"

/*
		stc 15w �汾 1.0	24.0 MHz
*/

extern unsigned char r_1,RXD_Flag;
extern int TCount,Timer0;
extern unsigned char array_r[16],array_s[16];


void Uart_Init(unsigned char x);
void Clean(unsigned char Length, unsigned char *Opinter);				//x�� ���� , y�� �׵�ַ
void UARTX_Send(unsigned char Channels,char *Opinter,unsigned char Length);


#endif
